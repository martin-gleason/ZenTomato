# Handoff: v1.5 Upgrade

Target repo: `martin-gleason/ZenTomato` (main). This bundle specifies the ZenTomato 1.5 polish pass: the garden surface, themes, the Ensō block style, the Dynamic Island tomato, and the reorganized Settings sheet.

## Overview

ZenTomato 1.5 adds four features on top of the shipping v0.1 timer:

1. **Garden** — a third surface (beside timer and history) that draws completed pomodoros as tomatoes. Quiet-gamification guardrails are part of the spec, not decoration.
2. **Themes** — seven entries (Auto + six) implemented as second token tables behind the existing `ColorRole` semantic roles.
3. **Ensō circle block style** — an optional replacement for the sprint rule's progress reading: a calligraphic brush stroke that draws itself around the music line as the block elapses.
4. **Island tomato ("Ripen")** — the Dynamic Island compact/minimal glyph becomes a tomato that fills with red as the block runs, derived purely from start/end dates.

Settings is restructured into three groups (Integrations / Theme / Focus settings), and the Lock Screen card inherits the theme accent.

## About the design files

The files in this bundle are **design references created in HTML** — a working prototype showing intended look and behavior, not production code. The task is to **recreate these designs in the ZenTomato SwiftUI codebase** using its established design system (`Palette.swift`, `ColorRole.swift`, `Typography.swift`, `Spacing.swift`, `Radius.swift`) and patterns. Where the prototype and the repo's conventions differ, the repo's conventions win — the prototype approximates SF system fonts and iOS controls in CSS.

## Fidelity

**High-fidelity.** Colors, spacing, type roles, and layout are exact and traced from the repo's own token files (see `recreation-notes.md` for the full transcription). Recreate pixel-perfectly using the existing role/token system — every hex below already exists in `Palette.swift` or is a new token this delta introduces.

## ⚠ Scope gates — read before building

This is a **delta proposal**, not ratified spec. Do not merge any piece before its delta is ratified on the board:

- **D-A Themes** — reverses README's "there is no theme picker, and there will not be one."
- **D-B Garden** — SPEC v0.1 lists "streaks, badges, or any gamification" as out of scope (Phase 2). The guardrails below must be written into the ratified delta.
- **D-C Island tomato** — content-only Live Activity change; behavior unchanged (no `.update()` anywhere).
- **D-D Third surface** — a second glyph joins the timer's top-left corner; the alternative is a tab inside the history sheet.
- **Spotify / YouTube Music** — the Settings mock shows them as selectable services, but SPEC locks music to Apple Music (MusicKit) and CLAUDE.md forbids network calls beyond Todoist + MusicKit. **Each new service is its own spec delta** (allowlist endpoints, new auth). Build the row format now; wire only Apple Music.

## Design tokens

### Base roles (existing — `ColorRole.swift`), light / dark

- surfacePrimary `#F6F5F2` / `#1C1F22` · surfaceRaised `#FFFFFF` / `#24282C` · surfaceInset `#E7E4DB` / `#17191C`
- textPrimary `#22252A` / `#ECE8DF` · textMuted `#5C5A52` / `#B3AEA3` · textSubtle `#6F6C63` / `#948F84`
- border `#DEDBD4` / `#3A3F45` · borderStrong `#828074` (both)
- action `#5C7040` / `#8AA163` · actionActive `#3F4C2D` / `#AEC48B` · onAction `#F6F5F2` / `#1C1F22` · actionSubtle `#E7EBDC` / `#2B3226`
- warning fill `#BD8024` / `#D99A3E` · onWarning `#22252A` / `#1C1F22` · warningText `#8A5E14` / `#DFA858`
- danger `#C0392B` / `#E06A50` · dangerText `#C0392B` / `#E67D65` · focus = action

### Theme tables (new)

Every theme is a full role table; screens keep naming roles, so contrast tests keep meaning something. Accent swaps override only `action`/`actionActive` (+ `onAction` where needed); full palettes re-derive grounds and ink.

| Theme | Kind | action light / dark | Other overrides |
|---|---|---|---|
| Sage | ships today | `#5C7040` / `#8AA163` | none (reference; Auto's fallback) |
| Ripen | accent swap | `#C0392B` / `#E06A50` | none — red600 is 4.99:1 on stone, already a measured role (danger) |
| Teal | accent swap | `#2E6E66` / `#7FB5AC` | oklch-matched to sage600 lightness |
| Plum | accent swap | `#6E4870` / `#B394B5` | same lightness discipline |
| Matcha | full palette | sage (unchanged) | light: surface `#F1F3EA`, raised `#FAFBF5`, inset `#E2E6D6`, ink `#232820`, muted `#575E4E`, subtle `#6B7261`; dark: surface `#1B1F19`, raised `#232820`, inset `#15180F` |
| Ink | full palette | `#33383D` / `#C8CCD0` | light: surface `#F4F4F3`, raised `#FFFFFF`, inset `#E6E6E4`, onAction `#F4F4F3`; dark: surface `#141618`, raised `#1D2023`, inset `#0F1113`, onAction `#141618` |

**Auto** (default, top of picker): season + clock decide. Hour < 6 or ≥ 21 → Ink; month is August or September → Ripen; otherwise Sage. Light/dark appearance still follows the phone independently of theme.

Re-measure every pairing of a full palette before it ships (the repo's AA test harness).

### Typography (SF system — no custom faces)

- numeral: 96pt, weight 500, monospaced digits, tracking −0.015em (ratio × size). Garden stat numeral: 48pt.
- kicker: caption (12pt) monospaced semibold UPPERCASE, tracking 0.06em
- label 15pt medium · body 17pt · button headline 17pt semibold · data footnote 13pt monospaced

### Spacing / radius

4px base: 2/4/8/12/16/24/32/48/64. controlHeight 44 (min-height, never fixed). Radius 2/3/4/6; buttons and cards 6, continuous. Borders 1/2/3px.

## Screens / views

### 1. Timer screen (`TimerScreen.swift`) — changes only

The v0.1 layout is unchanged (see `recreation-notes.md` for the full top-to-bottom trace). 1.5 changes:

- **Top-left chrome**: garden glyph (a two-leaf sprout, 20×20 stroke 1.5, textMuted, 44×44 hit) joins the history glyph, side by side at top-left. Gear stays top-right. Three-button chrome rule: never more.
- **All colors read from the active theme table** — the kicker stays the screen's one accent color, now theme-driven.
- **Ensō block style** (when selected in Settings): see §4.

### 2. Garden (new surface)

Push/present from the garden glyph; "‹ Timer" back button top-left (15pt medium, textMuted, 44pt hit).

Layout top→bottom, surfacePrimary ground, padding-x 16:
- Centered header stack, gap 12: kicker "GARDEN" (action color) · today count (48pt numeral, textPrimary) · "tomatoes today" (label 15, textMuted) · row of tomato glyphs for today's harvest (24×26 each, gap 6, cap at 8, wraps centered).
- **Last 14 days bed**: mono kicker "LAST 14 DAYS" (textMuted), then a 7-column grid, gap 8. Each day cell (column, gap 4, padding 8×2, radius 4): a small tomato (16×18) + mono count, or — on a zero day — a **wilted stem** (thin curved stroke + drooping leaf in borderStrong at 55% opacity) + "—" in textSubtle. Today's cell: surfaceInset fill + 1px borderStrong. Day label under each (mono 10pt, textSubtle; "today" for the last).
- Caption under the bed (13pt textSubtle): "A quiet day wilts nothing you've grown. Nothing resets."
- **Milestone banner** (only when a lifetime milestone was just crossed): warning-fill background, radius 6, padding 12×16; mono kicker "MILESTONE" + line "100th tomato — grown this month." in onWarning ink. This is the screen's one amber thing.
- Footer row above a hairline top border: "Lifetime harvest" (label, textMuted) ↔ "{n} tomatoes" (mono 15, textPrimary).

Tomato glyph: circle r9 fill `#C0392B`, sepal crown fill `#4C5C36` (three triangles from the top point).

**Guardrails (spec, not suggestion):**
- Wilt, never reset — a missed day draws a wilted stem; no number ever goes down.
- No chain number — no streak count anywhere; continuity is visible in the bed itself.
- Lifetime milestones only (100th tomato etc.) — quiet amber line, never day-chain celebration.
- The timer screen is untouched — no count, sprout, or badge on the focus screen.

Data derives from the existing pomodoro log; unit = completed pomodoros.

### 3. Settings sheet (restructured)

Sheet with "Settings" title (17pt semibold) left, "Done" (17pt semibold, action color) right. Scrollable body, three groups, each a mono-uppercase kicker (textMuted) over a surfaceRaised card (1px border, radius 6, rows min-height 44, padding 12×16, hairline row dividers):

**Integrations**
- Music — value: `Music: {Service}. {Status}` where Service ∈ Apple Music / Spotify / YouTube Music and Status ∈ Ready / Connected. **Exactly one service connected at a time** — connecting one disconnects the current; the row always shows exactly one service. Chevron → service picker. (Spotify/YT Music are unratified deltas; see scope gates.)
- Todoist — value "Connected", chevron.

**Theme**
- Theme picker rows: Auto (top), Sage, Ripen, Teal, Plum, Matcha, Ink. Each row (min-height 56): a 3-swatch chip (surface/ink/action, 12×24 each) · name (15 medium) + description (13 textSubtle) · action-colored checkmark on the active row. Auto's description shows its current resolution: "Season and clock decide — now: {Theme}".
- Footnote under picker: "Auto follows the season and the clock: harvest reds in August–September daylight, ink after dark. Light and dark still follow the phone."
- Block style rows: "Rule — The hairline sprint rule — ships today" / "Ensō circle — A brush stroke draws itself around the music as the block runs", checkmark on active.
- Sound row: "Sound · Chime".

**Focus settings**
- Length of pomodoro · 25 min / Length of breaks · 5 / 15 min / Number of pomodoros · 4.

### 4. Ensō circle block style

When selected, a 176×176 canvas sits between the sprint rule and the music row (music line text centers inside the circle, max-width 116px, 13pt medium textMuted; the toggle and transport stay in the row below, centered).

Two layers:
- **Idle guide**: dotted circle r76, 1.5px, border color, dasharray 1 5, round caps.
- **The stroke** (action color, filled outline path — not a stroked circle): draws as the block elapses, progress = elapsed/total. Drawn like a real ensō, all as a function of **absolute position along the finished stroke** (laid ink is immutable; only the tip advances):
  - One continuous sweep, 336° of arc starting at −90° (top), leaving the circle **open** at completion.
  - Landing attack with a pooled press (width swells ~28% around 13° in).
  - Speed-signature width: wider top/bottom (slow hand), thinner at the sides (fast) — `w = wMax(0.72 + 0.28|sin θ|)`, wMax 10.
  - Ink depletion: width × (1 − 0.38·a/336) over the sweep.
  - Kasure tail: from 292° the stroke dries — width collapses ~82% with a broken sin-modulated trail, plus two thin dry-brush streak paths riding beside the spine (offsets +3.4/−3.1, widths 22%/16%, opacities 0.5/0.35).
  - Fukinsei wobble on the spine radius: three stacked sines (amplitudes 3%/1.6%/0.8% of R), never smoothed.
  - Leading edge: pointed brush tip — width eases in over the last 12° behind the tip (pow 0.7) while drawing.

The exact generator is `ensoStroke()` in `ZenTomato 1.5.dc.html` — port the math verbatim (it is resolution-independent; render via SwiftUI `Path`/`Canvas`).

### 5. Live Activity & Dynamic Island

- **Lock card**: unchanged structure (kicker + self-driving countdown left, "2 OF 4" right, no controls, no imagery) but the kicker and tint now read the **theme's** roles instead of hard-coded sage — it already reads from the role table, so this is free.
- **Island** (always dark-resolved roles): the compact-leading / minimal `timer` glyph and the expanded leading glyph become the **Ripen tomato**: circle outline r9 (`#948F84` 1.2px), red `#E06A50` fill rising from the base as the block elapses (rect clipped to the circle, scaleY = progress, origin bottom), leaf crown `#8AA163` on top drawn over the fill. 24×26 viewBox as drawn; render at glyph size.
- **Breaks keep `cup.and.saucer`** — resting must never read as growing.
- Fill derives **purely from the block's start/end dates** (`ProgressView(timerInterval:)` idiom). The app pushes no updates; the repo's "search for `.update(` must find nothing" doctrine holds.
- Compact trailing countdown: footnote mono, max-width 56pt, minScale 0.7 (unchanged).

## Interactions & behavior

- Garden glyph → garden surface; back returns to timer. Gear → Settings sheet; Done dismisses.
- Theme pick applies instantly across app, Lock card, and (dark-resolved) island; persists.
- Block style pick swaps rule ↔ ensō on the timer screen; the sprint rule remains in both styles (the ensō replaces the *block-progress* reading, not the sprint count).
- Capture buttons flash surfaceInset for 180ms on tap (existing behavior).
- Motion: 100–260ms functional transitions only; no bounces, no confetti, no badges — completion is a quiet text line.

## State management

- `theme: ThemeID` (default `.auto`), `blockStyle: .rule | .enso` — persisted (UserDefaults/AppStorage).
- Auto resolution recomputed on foreground and hour change.
- Garden state = derived queries over the existing pomodoro log (today count, per-day counts for 14 days, lifetime total, milestone-crossing check). No new stored counters.
- Ensō progress = `1 − remaining/blockTotal` from the existing timer engine; 0 when idle.

## Assets

- App icon SVGs (existing): `Design/icon/AppIcon-{light,dark,tinted}.svg` — the ensō + tomato mark. Tomato glyph colors in-app key off it.
- No photos ship in-app (flat token surfaces rule). CC receipts for palette inspiration only: Wikimedia `File:Tomato.png` (CC0, shippable for README/App Store), `File:Tomato_plant.jpg` (CC BY-SA — inspiration only). Verify each file page before shipping anything.
- No icon font: all glyphs are SF Symbols in the app (`list.bullet.rectangle`, `gearshape`, `forward.end`, `stop.circle`, `timer`, `cup.and.saucer`) plus the custom tomato/sprout/wilt drawings specified above.

## Files in this bundle

- `ZenTomato 1.5.dc.html` — the working prototype (open in a browser; requires `support.js`, `ios-frame.jsx` alongside; the doc-page chrome references `_ds/` stylesheets not bundled here — the phone mock itself is self-contained and every value it uses is documented above). Contains the live timer engine, all three surfaces, the theme tables, and the `ensoStroke()` generator.
- `support.js`, `ios-frame.jsx` — prototype runtime; not for production.
- `recreation-notes.md` — the full v0.1 recreation trace from repo source (tokens, timer layout, Live Activity, states) — the pixel baseline 1.5 builds on.
- `Design/icon/AppIcon-*.svg` — app icon sources.
