# ZenTomato recreation notes (from repo source, main @2026-08-25)

## Tokens (Palette.swift / ColorRole.swift) — light / dark
surfacePrimary #F6F5F2 / #1C1F22 · surfaceRaised #FFF / #24282C · surfaceInset #E7E4DB / #17191C
textPrimary #22252A / #ECE8DF · textMuted #5C5A52 / #B3AEA3 · textSubtle #6F6C63 / #948F84
border #DEDBD4 / #3A3F45 · borderStrong #828074 (both)
action #5C7040 / #8AA163 · actionActive #3F4C2D / #AEC48B · onAction #F6F5F2 / #1C1F22 · actionSubtle #E7EBDC / #2B3226
warning(fill) #BD8024 / #D99A3E · onWarning #22252A / #1C1F22 · warningText #8A5E14 / #DFA858
danger #C0392B / #E06A50 · dangerText #C0392B / #E67D65 · focus = action
Ramps kept for reference: sage50 #E7EBDC 200 #AEC48B 300 #9CB377 400 #8AA163 500 #667A49(brand, never text) 600 #5C7040 700 #4C5C36 800 #3F4C2D 900 #2B3226; stone150 bone #ECE8DF; amber300 #DFA858 400 #D99A3E 500 #BD8024 700 #8A5E14; red300 #EC907A 400 #E67D65 500 #E06A50 600 #C0392B.

## Typography (SF system fonts; app uses NO custom faces)
numeral 96px weight 500 monospaced-digits, tracking -0.015em (ratio × size)
statNumeral = 48px. display=title bold; title=title2 semibold; body 17; bodyEmphasis semibold; label=subheadline(15) medium; button=headline(17 semibold); kicker=caption(12) monospaced semibold UPPERCASE; data=footnote(13) monospaced.

## Spacing/Radius
4px base: xxxs2 xxs4 xs8 sm12 md16 lg24 xl32 xxl48 xxxl64; controlHeight 44 (min-height, never fixed); borders 1/2/3. Radius: xs2 sm3 md4 lg6 (buttons 6, continuous). Sharp corners = brand signature.

## Timer screen (TimerScreen.swift) layout top→bottom
Page: surfacePrimary, padding-x 16, padding-bottom 24. No nav bar.
Overlay top-left: history glyph "list.bullet.rectangle", top-right gear "gearshape" — label font(15), textMuted, 44×44 hit, padding edge 16 / top 8.
Column: Spacer(min 32) → attachment line (label 15 med, textMuted, centered, chevron.right when tappable, minHeight 44, pb 12) → kicker (caption mono semibold uppercase, Color action — THE one colour on screen) gap 12 → numeral (96 med, textPrimary; textSubtle when not a live reading) → SprintProgress pt 24 → MusicRow pt 16 pb 16 → completionNote (label, textMuted, centered, pt 16, e.g. "Sprint complete — 4 pomodoros done.") → failureRow (amber warningText, exclamationmark.triangle, left-aligned, pt 16) → capture pair pt 32 → Spacer(min 48) → button.
Buttons: Start = filled action, onAction ink, headline, full width, minHeight 44, radius 6, pad-x16 y8. Disabled: surfaceInset fill + textSubtle ink + 1px borderStrong outline. Stop (running) = no fill, 1px borderStrong outline, textMuted ink (quiet), radius 6. Skip removed from app. Pressed: surfaceInset fill.
Sprint rule: full-width HStack bottom-aligned, gap 2; segment = flex-1 rect; finished: action fill, 4px tall; unfinished: borderStrong, 2px tall. During break the capture pair keeps its exact height, hidden.
Capture buttons: pair HStack gap 12, each flex-1: word (headline, textPrimary) + count under (footnote mono, textMuted, opacity 0 if 0), gap 4; pad x12 y16, minHeight 64, 2px borderStrong outline radius 6, no fill. Labels "Internal" / "External".
Music row: HStack gap 12 minHeight 44: iOS toggle (tint action when on, off default) · line (label 15 med, textMuted, 2-line reserved height, truncates, chevron when idle-tappable) · skip "forward.end" + stop "stop.circle"/"play.circle" glyph buttons 44×44 textMuted (hidden-but-reserved when not playing). Line copy e.g. "Deep Focus" / playing shows now-playing title.
States (preview fixtures): idle 25:00 "FOCUS" 0/4 Start; running 24:58 2/4 Stop+capture; taps 18:04 counts 2/1; break 04:31 "SHORT BREAK" 3/4, capture hidden-reserved, no skip; sprint complete 25:00 4/4 all-filled + note; capture-fail amber "That tap wasn't saved. Tap again."
Numeral format mm:ss, no hour carry (120:00). Idle numeral = full block length.

## Live Activity (BlockLiveActivity.swift)
Lock card: HStack lastTextBaseline gap 12, pad 16, bg surfacePrimary; left VStack gap 2: kicker (caption mono uppercase, action) + countdown (title2-ish "Typography.title" semibold, monospaced digits, textPrimary); right: "2 OF 4" (kicker style, textMuted, shrinks first). No controls on card, ever.
Dynamic Island: ALWAYS dark-resolved colours (islandInk = dark theme). Compact leading: glyph "timer" (work) / "cup.and.saucer" (break), footnote mono size, action colour (#8AA163). Compact trailing: countdown, footnote mono, max-width 56pt, minScale .7. Expanded: leading glyph+kicker, center countdown (title font), trailing sprint count. Minimal: glyph only.
Countdown is self-driving Text(timerInterval:) — app pushes NO updates; any tomato fill must derive purely from start/end dates (ProgressView(timerInterval:) idiom).

## App icon (AppIcon-light.svg)
bg #f6f5f2; ensō = tapered brush ring (filled outline path); tomato = circle r246 @(512,574) fill #c0392b; leaf crown 5 triangular sepals fill #4c5c36 (scaled .7, translated y266); stem rect 30×76 rx5 fill #3f4c2d. Dark icon presumably slate bg.

## 1.5 decisions (Marty, form rounds 1–2)
Gamification: garden metaphor + milestones; NOT addictive. Guardrails: grace days (wilt, never reset), lifetime milestones (100th tomato) not day-chains. Unit: pomodoros. Garden = its own third surface beside timer & history.
Themes: accent swaps + full palettes + seasonal/time-of-day; chooser = picker in Settings with "Auto" at top.
Island tomato: build ALL THREE metaphors side by side (ripen fill-up, ensō ring draw, drain down).
Photos: theme-inspiration palettes + shortlist w/ license receipts; in-app imagery flagged as breaking flat-surface rule. GPL repo → CC0/CC-BY only shippable; CC-BY-SA ok for inspiration.
Deliverable: working prototype; scope = timer screen all key states (+ island lab, garden, theme picker as presented concepts).
Spec friction to flag on board: SPEC v0.1 lists themes & gamification as out of scope (Phase 2) — 1.5 = ratifying deltas; README: "no theme picker" reversed by D-delta; "no confetti, no badge" ethos → quiet reward language.

## Handoff notes (Marty, m0057)
Settings → Integrations → Music row format: "Music: {Service}. {connection status}".
Services: Apple Music, Spotify, YouTube Music. Connection statuses: Ready, Connected.
Only ONE service can be connected at a time — connecting a service disconnects the current one; the row always shows exactly one service.
NB: Spotify + YouTube Music are new integrations — SPEC locks music source to Apple Music (MusicKit) and CLAUDE.md forbids network calls beyond Todoist + MusicKit, so each new service is its own spec delta (new endpoints on the allowlist, new auth).

## Research receipts
Apple HIG Live Activities: no buttons/button-like elements on lock card (app already complies); island best with no bg imagery, foreground elements only; timers self-update via timerInterval.
Todoist Karma: points+levels+streaks w/ vacation mode & disable option; failure modes = streak anxiety, point-yield task selection → our guardrails.
Pomodoro lit: structured breaks have mood/efficiency benefits (Biwer 2023); interrupted pomodoros lose effectiveness — log interruptions, return during breaks (= distraction log thesis); long break non-optional; 2025 MDPI study: pomodoro breaks can raise fatigue vs self-regulated — flexibility matters (settings already allow custom lengths).
CC tomato photos (Wikimedia Commons): File:Tomato.png = CC0 (receipt confirmed); File:Tomato_plant.jpg = CC BY-SA 3.0 (receipt confirmed); Category:Tomatoes has thousands more; verify each file page before shipping anything.
